#include<vector>
#include<iostream>
#include<algorithm>
#include<fstream>

using namespace std;

// Creating shortcut for an integer pair 
typedef  pair<int, int> iPair;

// Structure to represent a graph 
struct Graph
{
    int V, E;
    vector< pair<int, iPair> > edges;
    vector<int> visit;

    // Constructor 
    Graph(int V, int E)
    {
        this->V = V;
        this->E = E;
        this->visit = vector<int>(E, 0);
    }

    // Utility function to add an edge 
    void addEdge(int u, int v, int w)
    {
        edges.push_back({ w, {u, v} });
    }

    // Function to find MST using Kruskal's 
    // MST algorithm 
    int kruskalMST();
};

// To represent Disjoint Sets 
struct DisjointSets
{
    int* parent, * rnk;
    int n;

    // Constructor. 
    DisjointSets(int n)
    {
        // Allocate memory 
        this->n = n;
        parent = new int[n + 1];
        rnk = new int[n + 1];

        // Initially, all vertices are in 
        // different sets and have rank 0. 
        for (int i = 0; i <= n; i++)
        {
            rnk[i] = 0;

            //every element is parent of itself 
            parent[i] = i;
        }
    }

    // Find the parent of a node 'u' 
    // Path Compression 
    int find(int u)
    {
        /* Make the parent of the nodes in the path
           from u--> parent[u] point to parent[u] */
        if (u != parent[u])
            parent[u] = find(parent[u]);
        return parent[u];
    }

    // Union by rank 
    void merge(int x, int y)
    {
        x = find(x), y = find(y);

        /* Make tree with smaller height
           a subtree of the other tree  */
        if (rnk[x] > rnk[y])
            parent[y] = x;
        else // If rnk[x] <= rnk[y] 
            parent[x] = y;

        if (rnk[x] == rnk[y])
            rnk[y]++;
    }
};

/* Functions returns weight of the MST*/

int Graph::kruskalMST()
{
    int mst_wt = 0; // Initialize result 

    // Sort edges in increasing order on basis of cost 
    sort(edges.begin(), edges.end());

    // Create disjoint sets 
    DisjointSets ds(V);

    // Iterate through all sorted edges 
    vector< pair<int, iPair> >::iterator it;
    for (it = edges.begin(); it != edges.end(); it++)
    {
        int u = it->second.first;
        int v = it->second.second;
        

        int set_u = ds.find(u);
        int set_v = ds.find(v);

        // Check if the selected edge is creating 
        // a cycle or not (Cycle is created if u 
        // and v belong to same set) 
        if (set_u != set_v)
        {
            visit[distance(edges.begin(), it)] = 1;
            // Current edge will be in the MST 
            // so print it 
            cout << u << " - " << v << endl;

            // Update MST weight 
            mst_wt += it->first;

            // Merge two sets 
            ds.merge(set_u, set_v);
        }
    }

    return mst_wt;
}


// Driver program to test above functions 

int main(int argc, char* argv[])
{
    /* Let us create above shown weighted
       and unidrected graph */

    if (argc < 2)
        return 0;
    ifstream fin(argv[1]);
    //  making above shown graph 
    int V, E;
    fin >> V >> E;
    Graph g(V, E);
    for (int i = 0; i < V; i++) {
        for (int j = 0; j < V; j++) {
            int node;
            fin >> node;
            if (node != -1) {
                g.addEdge(node, i, j);
            }
        }
    }
    
    fin.close();
    cout << "Edges of MST are \n";
    int mst_wt = g.kruskalMST();

    cout << "\nWeight of MST is " << mst_wt;

    cout << "My student ID is 9644540677" << endl;
    cout << "Therefore the additional edges are:" << endl;
    int num = 7;
    for (int i = 0; i < E && num>0; i++) {
        if (g.visit[i] == 0) {
            num--;
            cout << g.edges[i].second.first << " - " << g.edges[i].second.second << endl;
        }
    }

    return 0;
}